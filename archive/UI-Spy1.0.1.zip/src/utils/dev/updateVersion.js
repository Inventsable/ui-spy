const chalk = require("chalk");
const fse = require("fs-extra");
const fs = require("fs");
const shell = require("shelljs");
const inquirer = require("inquirer");

// Box-style message for end
const boxen = require("boxen");
const BOXEN_OPTS = {
  padding: 1,
  margin: 1,
  align: "center",
  borderColor: "yellow",
  borderStyle: "round"
};

module.exports = {
  init: async function() {
    const extVersion = getExtVersion();
    const extName = getExtName();
    const extString = `${extName}${extVersion}`;

    console.log(
      boxen(`${extName} is currently v${chalk.yellow(`${extVersion}`)}`, {
        ...BOXEN_OPTS,
        ...{
          borderColor: "white"
        }
      })
    );
    await inquirer
      .prompt([
        {
          type: "confirm",
          name: "shouldUpdate",
          message: `Update version?`,
          default: true
        }
      ])
      .then(answer => {
        if (answer.shouldUpdate) {
          findTier(extVersion.split(".")).then(answerver => {
            let chosen = extVersion.split(".")[answerver.versionIndex];
            promptNewNumber(chosen).then(ans => {
              let newVersion = extVersion.split(".");
              newVersion[answerver.versionIndex] = ans.newTier;
              setExtVersion(extVersion, newVersion).then(updated => {
                console.log(`${chalk.green("✔ ")} Update successful!`);
                console.log(
                  boxen(`${extName} updated to v${updated}`, {
                    ...BOXEN_OPTS,
                    ...{
                      borderColor: "blue"
                    }
                  })
                );
              });
            });
          });
        } else {
          console.log(`👍  All right! No changes will be made.`);
          endMessage();
        }
      })
      .catch(err => {
        //
      });

    return "";
  }
};

async function findTier(original) {
  return await inquirer.prompt([
    {
      type: "list",
      name: "versionIndex",
      message: "Choose tier to update",
      choices: [
        {
          name: `Major (${original[0]}.x.x)`,
          value: 0
        },
        {
          name: `Minor (x.${original[1]}.x)`,
          value: 1
        },
        {
          name: `Micro (x.x.${original[2]})`,
          value: 2
        }
      ]
    }
  ]);
}

async function promptNewNumber(old) {
  return await inquirer.prompt([
    {
      type: "Number",
      message: "Enter new value for tier",
      default: +old + 1,
      name: "newTier"
    }
  ]);
}

function setExtVersion(older, newer) {
  return new Promise((resolve, reject) => {
    let xml = fs.readFileSync(`./CSXS/manifest.xml`, { encoding: "utf-8" });
    let rx = new RegExp(`${older.split(".").join("\\.")}`);
    xml = xml.split(rx).join(newer.join("."));
    fs.writeFileSync(`./CSXS/manifest.xml`, xml);
    resolve(newer.join("."));
  });
}

function getExtVersion() {
  const xml = fs.readFileSync(`./CSXS/manifest.xml`, { encoding: "utf-8" });
  const bundleVersion = /ExtensionBundleVersion\=\"(\d|\.)*(?=\")/;
  const matches = xml.match(bundleVersion);
  return matches.length ? matches[0].replace(/\w*\=\"/, "") : "Unknown";
}

function getExtName() {
  const xml = fs.readFileSync(`./CSXS/manifest.xml`, { encoding: "utf-8" });
  const bundleVersion = /Menu\>.*(?=\<)/;
  const matches = xml.match(bundleVersion);
  return matches.length
    ? matches[0]
        .replace(/Menu\>/, "")
        .split(" ")
        .join("-")
    : "Unknown";
}

// function switchContext() {
//   return new Promise((resolve, reject) => {
//     let xml = fs.readFileSync(`./CSXS/manifest.xml`, { encoding: "utf-8" });
//     const isDev = /\<\!\--\s\<MainPath\>\.\/dist\/index\.html\<\/MainPath\>\s\-\-\>/;
//     const isBuild = /\<\!\--\s\<MainPath\>\.\/public\/index\-dev\.html\<\/MainPath\>\s\-\-\>/;
//     const isDevVanilla = /\<MainPath\>\.\/dist\/index\.html\<\/MainPath\>/;
//     const isBuildVanilla = /\<MainPath\>\.\/public\/index\-dev\.html\<\/MainPath\>/;
//     const devString = `<MainPath>./public/index-dev.html</MainPath>`;
//     const buildString = `<MainPath>./dist/index.html</MainPath>`;
//     const commentedDevString = `<!-- <MainPath>./public/index-dev.html</MainPath> -->`;
//     const commentedBuildString = `<!-- <MainPath>./dist/index.html</MainPath> -->`;
//     if (isDev.test(xml)) {
//       xml = xml.replace(isDev, buildString);
//       xml = xml.replace(isBuildVanilla, commentedDevString);
//       fs.writeFileSync(`./CSXS/manifest.xml`, xml);
//       resolve("PRODUCTION");
//     } else if (isBuild.test(xml)) {
//       xml = xml.replace(isBuild, devString);
//       xml = xml.replace(isDevVanilla, commentedBuildString);
//       fs.writeFileSync(`./CSXS/manifest.xml`, xml);
//       resolve("DEVELOPER");
//     } else {
//       console.log("Whoops! Something went wrong.");
//     }
//   });
// }

require("make-runnable/custom")({
  printOutputFrame: false
});
