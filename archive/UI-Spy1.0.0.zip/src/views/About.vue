<template>
  <div class="about">
    <h1>This is an about page</h1>
  </div>
</template>

<style>
.about {
  width: 100%;
  display: flex;
  justify-content: center;
  color: var(--color-text-default);
}
</style>
